@extends('greeting.master')
@section('style')
    <style>
        video {
            display: block;
            margin: 20px auto;
            width: 90%;
            max-width: 500px;
        }

        fieldset {
            margin-top: 20px;
        }

        .action-button {
            font-weight: normal;
            font-size: 14px;
        }
    </style>
@stop
@section('form')
    {!! Form::open(['id'=>'greetingForm']) !!}
    <fieldset id="enterName">
    	<h2>فيديو التهنئة</h2>
        <div>
            <div class="url">
                <a href="{{url('vid/'.$Response[1])}}">{{url('vid/'.$Response[1])}}</a>

            </div>
            <!--<video controls>
	        	<source src='{{asset("$Response[0]")}}' type="video/mp4">
	        </video>-->
            <a class="action-button no-float" href="{{url('vid/'.$Response[1])}}"><i class="fa fa-download"></i>تحميل</a>

        </div>

    </fieldset>
    

    {!! Form::close()!!}
@stop
