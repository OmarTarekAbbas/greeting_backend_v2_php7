@extends('greeting.master')
@section('style')
    <style>

        fieldset {
            margin-top: 20px;
        }

        .action-button {
            font-weight: normal;
            font-size: 14px;
        }
    </style>
@stop
@section('form')
    {!! Form::open(['id'=>'greetingForm']) !!}

    <fieldset id="enterName">
        <a class="choose-link cf" href="{{ url('imgs/'.$UID) }}">
            <p>صور تهنئة</p> 
            <i class="fa fa-picture-o"></i>
        </a>
        <a class="choose-link cf" href="{{ url('vids/'.$UID) }}">
            <p>فيديو تهنئة</p>
            <i class="fa fa-film"></i>
        </a>

    </fieldset>

    {!! Form::close()!!}
@stop
